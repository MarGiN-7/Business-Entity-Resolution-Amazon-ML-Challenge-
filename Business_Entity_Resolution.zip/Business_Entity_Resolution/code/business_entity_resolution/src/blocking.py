from collections import defaultdict
from typing import Dict, List, Set, Tuple
import pandas as pd
import numpy as np
from .config import NGRAM_MIN, NGRAM_MAX, MAX_CANDIDATES_PER_S1
from .text_utils import (
    clean_text, tokenize, remove_suffixes, remove_stopwords, expand_abbrev,
    get_ngrams, get_tokens_set, name_soundex_keys, canonical_name, canonical_address,
    jaccard, dice_coeff,
)


class MultiKeyBlocker:
    def __init__(self, max_candidates: int = MAX_CANDIDATES_PER_S1):
        self.max_candidates = max_candidates
        self.inverted_indices: Dict[str, Dict[str, List[str]]] = defaultdict(
            lambda: defaultdict(list)
        )
        self.candidate_records: Dict[str, Dict] = {}
        self.s1_ids: List[str] = []

    def _country(self, rec: Dict) -> str:
        return rec.get("country", "").strip().lower() or ""

    def _name_all_tokens(self, text: str) -> List[str]:
        toks = remove_suffixes(tokenize(text))
        toks = [t for t in toks if len(t) >= 3]
        return toks

    def _addr_all_tokens(self, text: str) -> List[str]:
        toks = expand_abbrev(tokenize(text))
        toks = [t for t in toks if t.isdigit() or len(t) >= 3]
        return toks

    def _top_ngrams(self, text: str, k: int = 10) -> List[str]:
        ngrams = get_ngrams(text, NGRAM_MIN, NGRAM_MAX)
        if not ngrams:
            return []
        ngrams = sorted(ngrams, key=lambda x: len(x), reverse=True)
        return ngrams[:k]

    def _blocking_keys(self, rec: Dict) -> List[Tuple[str, str]]:
        c = self._country(rec)
        name = rec.get("business_name", "")
        addr = rec.get("business_address", "")
        keys = []

        def add(kt, kv, country_scope=True):
            if country_scope and c:
                keys.append((kt, f"{c}|{kv}"))
            keys.append((f"{kt}_X", f"XX|{kv}"))

        name_toks = self._name_all_tokens(name)
        addr_toks = self._addr_all_tokens(addr)

        for t in name_toks:
            add("N1", t.lower())
        for t in addr_toks:
            add("A1", t.lower())

        for i in range(len(name_toks) - 1):
            for j in range(i + 1, min(i + 3, len(name_toks))):
                a, b = sorted([name_toks[i].lower(), name_toks[j].lower()])
                add("N2", f"{a}|{b}")

        for i in range(len(addr_toks) - 1):
            for j in range(i + 1, min(i + 3, len(addr_toks))):
                a, b = sorted([addr_toks[i].lower(), addr_toks[j].lower()])
                add("A2", f"{a}|{b}")

        if name_toks and addr_toks:
            nt = name_toks[0].lower()
            for at in addr_toks[:2]:
                add("NA", f"{nt}|{at.lower()}")

        sx = name_soundex_keys(name)
        for s in sx[:3]:
            add("SX", s)

        can_n = canonical_name(name)
        can_a = canonical_address(addr)
        for ng in self._top_ngrams(can_n, 5):
            add("NGN", ng)
        for ng in self._top_ngrams(can_a, 5):
            add("NGA", ng)

        if name_toks:
            add("NFT", name_toks[0][:3].lower())
        if addr_toks:
            add("AFT", addr_toks[0][:3].lower())

        return list(set(keys))

    def fit(self, s2_df: pd.DataFrame, s3_df: pd.DataFrame) -> None:
        self.inverted_indices.clear()
        self.candidate_records.clear()
        df = pd.concat([s2_df, s3_df], axis=0, ignore_index=True)
        for _, row in df.iterrows():
            rid = row["entity_id"]
            rec = row.to_dict()
            self.candidate_records[rid] = rec
            for kt, kv in self._blocking_keys(rec):
                self.inverted_indices[kt][kv].append(rid)
        print(f"[blocker] indexed {len(self.candidate_records)} S2/S3 records")
        print(f"[blocker] {sum(len(v) for v in self.inverted_indices.values())} total key slots")

    def _quick_score(self, rec_a: Dict, rec_b: Dict) -> float:
        na = canonical_name(rec_a.get("business_name", ""))
        nb = canonical_name(rec_b.get("business_name", ""))
        aa = canonical_address(rec_a.get("business_address", ""))
        ab = canonical_address(rec_b.get("business_address", ""))
        n_tok_a = get_tokens_set(na, remove_suf=True, rm_stop=True)
        n_tok_b = get_tokens_set(nb, remove_suf=True, rm_stop=True)
        a_tok_a = get_tokens_set(aa, rm_stop=True)
        a_tok_b = get_tokens_set(ab, rm_stop=True)
        n_j = jaccard(n_tok_a, n_tok_b)
        n_d = dice_coeff(n_tok_a, n_tok_b)
        a_j = jaccard(a_tok_a, a_tok_b)
        a_d = dice_coeff(a_tok_a, a_tok_b)
        n_ng_a = get_ngrams(na, NGRAM_MIN, NGRAM_MAX)
        n_ng_b = get_ngrams(nb, NGRAM_MIN, NGRAM_MAX)
        a_ng_a = get_ngrams(aa, NGRAM_MIN, NGRAM_MAX)
        a_ng_b = get_ngrams(ab, NGRAM_MIN, NGRAM_MAX)
        nn_j = jaccard(n_ng_a, n_ng_b)
        aa_j = jaccard(a_ng_a, a_ng_b)
        ca = self._country(rec_a)
        cb = self._country(rec_b)
        if ca and cb:
            c_match = 1.0 if ca == cb else 0.0
        else:
            c_match = 0.5
        score = (
            0.25 * n_j + 0.10 * n_d + 0.15 * nn_j +
            0.10 * a_j + 0.05 * a_d + 0.10 * aa_j +
            0.10 * c_match + 0.15 * max(n_j, a_j, nn_j, aa_j)
        )
        return score

    def transform(self, s1_df: pd.DataFrame) -> Dict[str, List[str]]:
        candidates: Dict[str, List[str]] = {}
        raw_counts = []
        for _, row in s1_df.iterrows():
            s1_id = row["entity_id"]
            s1_rec = row.to_dict()
            self.s1_ids.append(s1_id)
            hit_scores: Dict[str, int] = defaultdict(int)
            for kt, kv in self._blocking_keys(s1_rec):
                if kv in self.inverted_indices[kt]:
                    for rid in self.inverted_indices[kt][kv]:
                        hit_scores[rid] += 1
            hits = set(hit_scores.keys())
            raw_counts.append(len(hits))
            if not hits:
                candidates[s1_id] = []
                continue
            scored = []
            for rid in hits:
                if rid == s1_id:
                    continue
                rec_b = self.candidate_records.get(rid)
                if rec_b is None:
                    continue
                sc = self._quick_score(s1_rec, rec_b)
                hit_boost = min(hit_scores[rid], 10) * 0.01
                scored.append((sc + hit_boost, rid))
            scored.sort(reverse=True)
            top_n = scored[: self.max_candidates]
            candidates[s1_id] = [rid for _, rid in top_n]
        if raw_counts:
            print(f"[blocker] pre-filter candidates per S1: "
                  f"min={min(raw_counts)}, avg={np.mean(raw_counts):.1f}, "
                  f"max={max(raw_counts)}")
        final_counts = [len(v) for v in candidates.values()]
        if final_counts:
            print(f"[blocker] post-filter candidates per S1: "
                  f"min={min(final_counts)}, avg={np.mean(final_counts):.1f}, "
                  f"max={max(final_counts)}, total={sum(final_counts)}")
        return candidates
